/* 페이지 로딩 후 실행 */
$(document).ready(function(){
	
	//클릭 이벤트
	//$(document).on('click', '선택자', function() {});
	
	
	
	//조인모달 열릴 때
	$(document).on('show.bs.modal', '#joinModal', function(){
		initJoinModal();
	});
	//조인모달 닫힐 때 
	$(document).on('hidden.bs.modal', '#joinModal', function(){
		//input 태그의 내용을 초기화
		$('#joinModal').find('form')[0].reset();
		
		//validate된 label 내용 삭제
		$('#joinForm label.error').remove();
	});
	
	
	//로그인모달 열릴 때
	$(document).on('show.bs.modal', '#loginModal', function(){
		initLoginModal();
	});
	//로그인모달 닫힐 때 
	$(document).on('hidden.bs.modal', '#loginModal', function(){
		//input 태그의 내용을 초기화
		$('#loginModal').find('form')[0].reset();
		
		//validate된 label 내용 삭제
		$('#loginForm label.error').remove();
	});
	
	//로그아웃 이벤트
	$(document).on('click','#logoutSpan',function(){
		alert('로그아웃되었습니다');
		location.href = 'logoutMember.me';
	});
	
	
});

/* 함수선언 영역*/
(function($){
	//aaa라는 함수선언
	//aaa = function(){
	
	//};
	
	initJoinModal = function(){
		//정규식 = Regular expression
		//아래의 정규식은 /정규식/i 형태로 작성
		//1) 숫자만 : ^[0-9]*$
		//2) 영문자만 : ^[a-zA-Z]*$
		//3) 한글만 : ^[가-힣]*$
		//4) 영어 & 숫자만 : ^[a-zA-Z0-9]*$
		//5) E-Mail : ^[a-zA-Z0-9]+@[a-zA-Z0-9]+$
		//6) 휴대폰 : ^01(?:0|1|[6-9])-(?:\d{3}|\d{4})-\d{4}$
		//7) 일반전화 : ^\d{2,3} - \d{3,4} - \d{4}$
		//8) 주민등록번호 : \d{6} \- [1-4]\d{6}
		
		//validate에 정규식 사용하게 설정
		//$.validator.addMethod('regx', function(value, element, regexpr){
		//   return regexpr.test(value);
		//});
		
		//validate(유효성 검사)
		$("#joinForm").validate({
	        //테스트를 위하여 유효성 검사가 완료되어도 submit을 처리하지 않음.
	        debug : false,
	        //유효성체크없이 무조건 submit
//	        onsubmit : false,
	        //focus가 들어왔을 때 유효성을 검사한다.
	        onfocusin : false,
	        //키보드로 입력할 때 유효성 검사
	        onkeyup : false,
	        //focus에서 떠날 때 유효성 검사
	        onfocusout : function(element) { $(element).valid(); },

	        
	        //검사할 필드와 검사 항목의 나열
//	        groups:{
//	           socialNum : 'socialNum1 socialNum2',
//	           emergencyPhoneNum : 'emergencyPhoneNum2 emergencyPhoneNum3',
//	           phoneNum : 'phoneNum2 phoneNum3'
//	        },
	        
	        //name속성을 찾는다.
	        rules : {
	          // className:{
	          //    required : true                //필수여부 지정
	                //digits : true,               //숫자만 입력 지정
	               // email : true,                //이메일만 입력 지정
	               // url : true,                  //url만 입력 지정
	               // minlength : 4,               //최소길이 지정
	               // maxlength : 8,               //최대길이 지정
	               // equalTo : 대상요소의 id 값 //특정 요소와 입력값이 같은지 여부 검사
	          // },
	           memberId : {
	              required : true,
	              minlength : 2,
	             maxlength : 10,
	             regx:/^[a-zA-Z0-9]*$/i //영어&숫자만
	           },
	           memberPassword : {
	        	   required : true,
	        	   minlength : 4,
	               maxlength : 20
	           },
		       memberPassword1 : {
		    	   required : true,
		    	   minlength : 4,
		    	   maxlength : 20,
		    	   equalTo : inputPassword
		       },
		       memberName : {
		    	   required : true,
		    	   minlength : 3,
		    	   maxlength : 5
		       },
		       tel1 : {
		    	   regxTel : /^01(?:0|1|[6-9])-(?:\d{3}|\d{4})-\d{4}$/i,
		    	   minlength : 11,
		    	   maxlength : 13
		       },
		       tel2 : {
		    	   regxTel : /^01(?:0|1|[6-9])-(?:\d{3}|\d{4})-\d{4}$/i,
		    	   minlength : 11,
		    	   maxlength : 13
		    	   
		       },
		       email : {
		    	   email : true,
		    	   regxEmail :  /^[a-zA-Z0-9]+@[a-zA-Z0-9]+$/i,
		    	   maxlength : 25
		       },
		       birthdayYear : {
		    	   required : true,
		    	   digits : true,
		    	   min : 1960,
		    	   max : 2021
		       },
		       birthdayMonth : {
		    	   required : true,
		    	   digits : true,
		    	   min : 1,
		    	   max : 12
		    	   
		       },
		       birthdayDay : {
		    	   required : true,
		    	   digits : true,
		    	   min : 1,
		    	   max : 31
		    	   
		       },
		       memberAddr : {
		    	   minlength : 2,
		    	   maxlength : 50
		       }
	        },
	        //검사를 충족하지 못할 경우 표시될 메시지의 나열                                                         
	        messages : {
	          // className : "과정명을 입력하세요.",
	          // className : {
	          //      required : "필수 입력 항목 입니다.",
	           //     number : "숫자만 입력하세요.",
	          //      minlength : "최소 {0}글자 입니다.",
	           //     maxlength : "최대 {0}글자 입니다.",
	           //     equalTo : "입력이 잘못되었습니다."
	           // },
	           //memberId:'ID를 입력하세요',
	           memberId : {
	        	   required : 'ID는 필수항목입니다',
	               minlength :'ID는 {0}자 이상 입력해주세요',
	               maxlength :'ID는 {0}자를 초과할 수 없습니다',
	               regx:'영어와 숫자만 사용가능합니다'
	           },
	           memberPassword : {
	        	   required : '비밀번호는 필수항목입니다',
	        	   minlength :'비밀번호는 {0}자 이상 입력해주세요',
	        	   maxlength :'비밀번호는 {0}자를 초과할 수 없습니다'
	        	   
	           },
	           memberPassword1 : {
	        	   required : '비밀번호는 필수항목입니다',
	        	   minlength : '비밀번호는 {0}자 이상 입력해주세요',
	        	   maxlength : '비밀번호는 {0}자를 초과할 수 없습니다',
	        	   equalTo : '비밀번호가 같지 않습니다'
	           },
	           memberName : {
	        	   required : '이름이 없는 사람은 없어요',
	        	   minlength : '이름은 {0}자 이상 입력해주세요',
	        	   maxlength : '이름은 {0}자를 초과할 수 없습니다',
	           },
		       tel1 : {
		    	   regxTel : '연락처를 정확히 입력해주세요',
		    	   minlength : '연락처는 {0}자 이상 입력해주세요',
		    	   maxlength : '연락처는 {0}를 초과할 수 없습니다'
		       },
		       tel2 : {
		    	   regxTel : '연락처를 정확히 입력해주세요',
		    	   minlength : '연락처는 {0}자 이상 입력해주세요',
		    	   maxlength : '연락처는 {0}를 초과할 수 없습니다'
		       },
		       email : {
		    	   email : '이메일을 정확히 입력해주세요',
		    	   regxEmail :  '이메일을 정확히 입력해주세요',
		    	   maxlength : '이메일은 {0}를 초과할 수 없습니다'
		       },
		       birthdayYear : {
		    	   required : '비우지마',
		    	   digits : '숫자만 입력해주세요',
		    	   min : '{0}년 이상 입력해주세요',
		    	   max : '{0}년 초과할 수 없습니다'
		       },
		       birthdayMonth : {
		    	   required : '비우지마',
		    	   digits : '숫자만 입력해주세요',
		    	   min : '{0}월 이상 입력해주세요',
		    	   max : '{0}월 초과할 수 없습니다'
		       },
		       birthdayDay : {
		    	   required : '비우지마',
		    	   digits : '숫자만 입력해주세요',
		    	   min : '{0}일 이상 입력해주세요',
		    	   max : '{0}일 초과할 수 없습니다'
		       },
		       memberAddr : {
		    	   minlength : '주소는 {0}자 이상 입력해주세요',
		    	   maxlength : '주소는 {0}를 초과할 수 없습니다'
		       }
	        },
	        //유효성 검사 실패 시 메세지의 출력 방식을 설정
	        errorPlacement: function(error, element){
	           error.insertAfter(element);
	        },
	        //유효성 검사 완료(성공) 후 실행할 코드
	        submitHandler: function(form) {
	        	form.submit();
	          // $( "#dialog-confirm" ).dialog( "open" );
	        }
	   });
	};
	
	initLoginModal = function(){
		//validate(유효성 검사)
		$("#loginForm").validate({
	        //테스트를 위하여 유효성 검사가 완료되어도 submit을 처리하지 않음.
	        debug : false,
	        //유효성체크없이 무조건 submit
//	        onsubmit : false,
	        //focus가 들어왔을 때 유효성을 검사한다.
	        onfocusin : false,
	        //키보드로 입력할 때 유효성 검사
	        onkeyup : false,
	        //focus에서 떠날 때 유효성 검사
	        onfocusout : function(element) { $(element).valid(); },

	        
	        //검사할 필드와 검사 항목의 나열
//	        groups:{
//	           socialNum : 'socialNum1 socialNum2',
//	           emergencyPhoneNum : 'emergencyPhoneNum2 emergencyPhoneNum3',
//	           phoneNum : 'phoneNum2 phoneNum3'
//	        },
	        
	        //name속성을 찾는다.
	        rules : {
	          // className:{
	          //    required : true                //필수여부 지정
	                //digits : true,               //숫자만 입력 지정
	               // email : true,                //이메일만 입력 지정
	               // url : true,                  //url만 입력 지정
	               // minlength : 4,               //최소길이 지정
	               // maxlength : 8,               //최대길이 지정
	               // equalTo : 대상요소의 id 값 //특정 요소와 입력값이 같은지 여부 검사
	          // },
	           memberId : {
	              required : true,
	              minlength : 2,
	             maxlength : 10,
	             regx:/^[a-zA-Z0-9]*$/i //영어&숫자만
	           },
	           memberPassword : {
	        	   required : true,
	        	   minlength : 4,
	               maxlength : 20
	           }
	        },
	        //검사를 충족하지 못할 경우 표시될 메시지의 나열                                                         
	        messages : {
	          // className : "과정명을 입력하세요.",
	          // className : {
	          //      required : "필수 입력 항목 입니다.",
	           //     number : "숫자만 입력하세요.",
	          //      minlength : "최소 {0}글자 입니다.",
	           //     maxlength : "최대 {0}글자 입니다.",
	           //     equalTo : "입력이 잘못되었습니다."
	           // },
	           //memberId:'ID를 입력하세요',
	           memberId : {
	        	   required : 'ID는 필수항목입니다',
	               minlength :'ID는 {0}자 이상 입력해주세요',
	               maxlength :'ID는 {0}자를 초과할 수 없습니다',
	               regx:'영어와 숫자만 사용가능합니다'
	           },
	           memberPassword : {
	        	   required : '비밀번호는 필수항목입니다',
	        	   minlength :'비밀번호는 {0}자 이상 입력해주세요',
	        	   maxlength :'비밀번호는 {0}자를 초과할 수 없습니다'
	           }
	        },
	        //유효성 검사 실패 시 메세지의 출력 방식을 설정
	        errorPlacement: function(error, element){
	           error.insertAfter(element);
	        },
	        //유효성 검사 완료(성공) 후 실행할 코드
	        submitHandler: function(form) {
	        	form.submit();
	          // $( "#dialog-confirm" ).dialog( "open" );
	        }
	   });
		
	};
	
})(jQuery);