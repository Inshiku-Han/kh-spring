package com.spring.biz.vo;

public class BaseVO {
	private String mainMenu;
	private int sideMenu;

	public BaseVO(){
		mainMenu = "shop";
		sideMenu = 1;
	}
	public String getMainMenu() {
		return mainMenu;
	}

	public void setMainMenu(String mainMenu) {
		this.mainMenu = mainMenu;
	}

	
	public int getSideMenu() {
		return sideMenu;
	}
	public void setSideMenu(int sideMenu) {
		this.sideMenu = sideMenu;
	}
	
	
	
}
