package com.spring.view;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.biz.vo.MemberVO;

@Controller
public class AdminController {
//	@Resource(name = "adminService")
//	AdminService adminService;
	
	//구매관리
	@RequestMapping(value = "/manageBuy.ad")
	public String manageBuy(MemberVO memberVO) {
		
		return "admin/manageBuy"; 
	}
	//상품등록
	@RequestMapping(value = "/addProduct.ad")
	public String addProduct(MemberVO memberVO) {
		
		return "admin/addProduct"; 
	}
	//상품관리
	@RequestMapping(value = "/manageProduct.ad")
	public String manageProduct(MemberVO memberVO) {
		
		return "admin/manageProduct"; 
	}
	//회원관리
	@RequestMapping(value = "/manageMember.ad")
	public String manageMember(MemberVO memberVO) {
		
		return "admin/manageMember"; 
	}
	
	
}










