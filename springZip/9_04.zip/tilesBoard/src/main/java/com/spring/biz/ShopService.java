package com.spring.biz;

import java.util.List;

import com.spring.biz.vo.CategoryVO;
import com.spring.biz.vo.GoodsVO;
import com.spring.biz.vo.ImageVO;

public interface ShopService {
	//상품 카테고리 리스트 조회
	List<CategoryVO> selectCategoryList();
	
	//상품등록
	void insertGoods(GoodsVO goodsVO, ImageVO imageVO);
	
	//상품 첨부파일 이미지 등록
	int insertImage(ImageVO imageVO);
	
	//상품ID 조회
	int getMaxId();
	
	//상품 목록 조회
	List<GoodsVO> selectGoodsList(GoodsVO goodsVO);
	
	//상품상세 조회
	GoodsVO selectGoods(GoodsVO goodsVO);
	
	//상품상세 이미지 조회
	List<ImageVO> selectGoodsImages(int goodsId);
}




















