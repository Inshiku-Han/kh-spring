package com.spring.biz.vo;

public class BuyVO extends BaseVO{
	private String orderNum;
	private String orderId;
	private String memberId;
	private String memberName;
	private String goodsId;
	private String goodsName;
	private String orderGoodsCnt;
	private String orderPrice;
	private String memberTel1;
	private String memberTel2;
	private String memberAddr;
	
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getOrderGoodsCnt() {
		return orderGoodsCnt;
	}
	public void setOrderGoodsCnt(String orderGoodsCnt) {
		this.orderGoodsCnt = orderGoodsCnt;
	}
	public String getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(String orderPrice) {
		this.orderPrice = orderPrice;
	}
	public String getMemberTel1() {
		return memberTel1;
	}
	public void setMemberTel1(String memberTel1) {
		this.memberTel1 = memberTel1;
	}
	public String getMemberTel2() {
		return memberTel2;
	}
	public void setMemberTel2(String memberTel2) {
		this.memberTel2 = memberTel2;
	}
	public String getMemberAddr() {
		return memberAddr;
	}
	public void setMemberAddr(String memberAddr) {
		this.memberAddr = memberAddr;
	}
	@Override
	public String toString() {
		return "BuyVO [orderNum=" + orderNum + ", orderId=" + orderId + ", memberId=" + memberId + ", memberName="
				+ memberName + ", goodsId=" + goodsId + ", goodsName=" + goodsName + ", orderGoodsCnt=" + orderGoodsCnt
				+ ", orderPrice=" + orderPrice + ", memberTel1=" + memberTel1 + ", memberTel2=" + memberTel2
				+ ", memberAddr=" + memberAddr + "]";
	}
	
	
}
