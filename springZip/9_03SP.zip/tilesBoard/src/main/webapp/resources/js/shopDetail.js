/* 페이지 로딩 후 실행 */
$(document).ready(function(){
	
	//클릭 이벤트
	//$(document).on('click', '선택자', function() {

	//});
	$(document).on('click', '#buyBtn', function() {
		const accountId = $('#accountId').val();
		
		if(accountId == ''){
			alert('로그인 안했으면 못사');
		}else{
			$('#buyModal').modal();
		}
		
		const goodsPrice = $('#goodsPrice').text(); //가격
		const cnt = $('#goodsCnt').val(); //수량
		const deliveryPrice = $('#deliveryPrice').text(); //배송비
		const totalPrice = goodsPrice * cnt + (deliveryPrice * 1); //합
		
		$('#totalPrice').text(`${totalPrice}만큼 flex해버렸지 뭐야~`);
	});
	
	
	$(document).on('click', '#buyModalBtn', function() {
			location.href='buyPage.sh';
		});
	
});

/* 함수선언 영역*/
(function($){
	//aaa라는 함수선언
	//aaa = function(){
	
	//};
	
})(jQuery);