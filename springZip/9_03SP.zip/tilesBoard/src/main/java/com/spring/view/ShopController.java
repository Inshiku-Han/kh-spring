package com.spring.view;


import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.biz.ShopService;
import com.spring.biz.vo.GoodsVO;

@Controller
public class ShopController {
	@Resource(name = "shopService")
	ShopService shopService;
	
	//쇼핑하기
	@RequestMapping(value = "/shopList.sh")
	public String shopList(GoodsVO goodsVO, Model model) {
		
		//상품조회
		model.addAttribute("goodsList", shopService.selectGoodsList(goodsVO));
		//카테고리조회
		model.addAttribute("categoryList", shopService.selectCategoryList());
		
		return "shop/shopList"; 
	}
	
	
	
	//상품 상세
	@RequestMapping(value = "/shopDetail.sh")
	public String shopDetail(GoodsVO goodsVO, Model model) {
		
		//카테고리조회
		model.addAttribute("categoryList", shopService.selectCategoryList());
		
		model.addAttribute("goods", shopService.selectGoods(goodsVO));
		
		model.addAttribute("images", shopService.selectSubImage(goodsVO));
		return "shop/shopDetail";
	}
	
	//구매 페이지
	@RequestMapping(value = "/buyPage.sh")
	public String buyPage() {
		
		
		return "shop/buyPage";
	}
	
}










