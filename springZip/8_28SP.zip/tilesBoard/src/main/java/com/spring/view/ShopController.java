package com.spring.view;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.biz.ShopService;
import com.spring.biz.vo.MemberVO;

@Controller
public class ShopController {
	@Resource(name = "shopService")
	ShopService shopService;
	
	//쇼핑하기
	@RequestMapping(value = "/shopList.sh")
	public String shopList(MemberVO memberVO) {
		return "shop/shopList"; 
	}
	
	
}










