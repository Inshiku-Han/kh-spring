package com.spring.biz;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.vo.CategoryVO;
import com.spring.biz.vo.GoodsVO;

@Service("shopService") 
//StudentServiceImpl studentService = new StudentServiceImpl();
public class ShopServiceImpl implements ShopService{
	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public List<CategoryVO> selectCategoryList() {
		return sqlSession.selectList("selectCategoryList");
	}

	@Override
	public int insertGoods(GoodsVO goodsVO) {
		return sqlSession.insert("insertGoods", goodsVO);
	}
	
}












