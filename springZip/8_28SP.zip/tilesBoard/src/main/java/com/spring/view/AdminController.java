package com.spring.view;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.biz.ShopService;
import com.spring.biz.vo.GoodsVO;
import com.spring.biz.vo.MemberVO;

@Controller
public class AdminController {
	@Resource(name = "shopService")
	ShopService shopService;
	
	//구매관리
	@RequestMapping(value = "/manageBuy.ad")
	public String manageBuy(MemberVO memberVO) {
		
		return "admin/manageBuy"; 
	}
	//상품등록 페이지
	@RequestMapping(value = "/addProduct.ad")
	public String addProduct(MemberVO memberVO,Model model) {
		model.addAttribute("categoryList", shopService.selectCategoryList());
		return "admin/addProduct"; 
	}
	//상품관리
	@RequestMapping(value = "/manageProduct.ad")
	public String manageProduct(MemberVO memberVO) {
//		shopService.
		return "admin/manageProduct"; 
	}
	//회원관리
	@RequestMapping(value = "/manageMember.ad")
	public String manageMember(MemberVO memberVO) {
		
		return "admin/manageMember"; 
	}
	//상품등록
	@RequestMapping(value = "/insertGoods.ad")
	public String insertGoods(GoodsVO goodsVO, HttpSession session) {
		
		String memberId = ((MemberVO)session.getAttribute("account")).getMemberId();
		goodsVO.setGoodsWriter(memberId);
		
		shopService.insertGoods(goodsVO);
		
		return "redirect:addProduct.ad"; 
	}
}










