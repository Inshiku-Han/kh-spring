package com.spring.biz;

import java.util.List;

import com.spring.biz.vo.CategoryVO;
import com.spring.biz.vo.GoodsVO;

public interface ShopService {
	//상품 카테고리 리스트 조회
	List<CategoryVO> selectCategoryList();
	//상품 등록
	int insertGoods(GoodsVO goodsVO);
}




















