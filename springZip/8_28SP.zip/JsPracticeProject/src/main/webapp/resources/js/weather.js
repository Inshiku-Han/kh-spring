//스토리지에 넣을 이름
const COORDS = 'coords';


//coords라는 key에 value 값 넣기
function saveCoords(coordsObj){ 
	localStorage.setItem(COORDS, JSON.stringify(coordsObj));
}


//위치 확인 수락 시
function handleGeoSuccess(position){
	const latitude = position.coords.latitude; //위도
	const longitude = position.coords.longitude; //경도
	const coordsObj = { //객체 하나에 담기
			latitude : latitude,
			longitude : longitude
	};
	saveCoords(coordsObj);
}


//위치확인 거절 시
function handleGeoError(){
	console.log("Can't access geo location")
}


//위치확인허용 질문
function askForCoords(){
	navigator.geolocation.getCurrentPosition(handleGeoSuccess, handleGeoError);
}


//스토리지에 위치정보있는지 확인
function loadCoords(){
	const loadedCords = localStorage.getItem(COORDS);
	if(loadedCords === null){
		askForCoords();
	}
//	else{
//		// getWeather
//	}
}


//시작
function init(){
	loadCoords();
}

init();