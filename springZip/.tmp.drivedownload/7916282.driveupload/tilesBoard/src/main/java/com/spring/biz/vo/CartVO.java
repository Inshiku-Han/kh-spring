package com.spring.biz.vo;

public class CartVO extends BaseVO {
	private String cartId;
	private int goodsId;
	private String memberId;
	private String createDate;
	private int goodsCnt;
	private String isDelete;
	
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public int getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public int getGoodsCnt() {
		return goodsCnt;
	}
	public void setGoodsCnt(int goodsCnt) {
		this.goodsCnt = goodsCnt;
	}
	public String getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(String isDelete) {
		this.isDelete = isDelete;
	}
	@Override
	public String toString() {
		return "CartVO [cartId=" + cartId + ", goodsId=" + goodsId + ", memberId=" + memberId + ", createDate="
				+ createDate + ", goodsCnt=" + goodsCnt + ", isDelete=" + isDelete + "]";
	}

	
	
	
}
