package com.spring.biz.vo;

public class SampleVO {
	private String sample;

	public String getSample() {
		return sample;
	}

	public void setSample(String sample) {
		this.sample = sample;
	}

	@Override
	public String toString() {
		return "SampleVO [sample=" + sample + "]";
	}
	
}










