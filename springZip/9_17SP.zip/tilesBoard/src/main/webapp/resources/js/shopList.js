/* 페이지 로딩 후 실행 */
$(document).ready(function(){
	//클릭 이벤트
	//$(document).on('click', '.imgDiv', function() {
		//goDetailPage();
		//$('#bodyDiv').empty();
		//$('#bodyDiv').load('shopList.sh');
	//});
});

/* 함수선언 영역*/
(function($){
	
	
})(jQuery);