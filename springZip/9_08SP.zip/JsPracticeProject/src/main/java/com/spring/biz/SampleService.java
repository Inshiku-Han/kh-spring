package com.spring.biz;


public interface SampleService {
	
}




















