import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		
		while(sc.hasNext()) {
			double a = sc.nextInt();
			double b = sc.nextInt();
			
			System.out.println(a + b);
			
		}
		
		sc.close();
		
	}

}
